"""Conservative decisions from structured task-consequence evidence.

The upstream vision/VLM component is not trusted to issue robot commands.  It
must provide calibrated, bounded evidence; this module turns that evidence
into a typed diagnosis or explicitly abstains.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from .events import EventType, MonitorEvent, RecommendedAction


@dataclass(frozen=True)
class SemanticConsequenceEvidence:
    observable: bool
    calibrated: bool
    goal_satisfied_score: float | None = None
    progress_score: float | None = None
    no_progress_score: float | None = None
    wrong_object_score: float | None = None
    object_lost_score: float | None = None
    metadata: Mapping[str, object] | None = None


@dataclass(frozen=True)
class SemanticConsequenceDecision:
    state: str
    score: float
    confidence: float
    reason: str


class SemanticConsequenceGate:
    """Require a strong winning score and abstain on conflicts.

    Scores are calibrated evidence values, not assumed posterior probabilities.
    A high anomaly score cannot override equally strong goal-satisfied evidence.
    """

    def __init__(self, *, minimum_score: float = 0.7, minimum_margin: float = 0.15):
        if not 0 <= minimum_score <= 1 or not 0 <= minimum_margin <= 1:
            raise ValueError("semantic consequence thresholds must lie in [0, 1]")
        self.minimum_score = minimum_score
        self.minimum_margin = minimum_margin

    @staticmethod
    def _valid(value: float | None) -> bool:
        return value is not None and 0 <= value <= 1

    def decide(self, evidence: SemanticConsequenceEvidence) -> SemanticConsequenceDecision:
        if not evidence.observable:
            return SemanticConsequenceDecision("unknown", 0.0, 0.0, "task consequence is not visible")
        if not evidence.calibrated:
            return SemanticConsequenceDecision("unknown", 0.0, 0.0, "semantic evidence is uncalibrated")
        candidates = {
            "goal_achieved": evidence.goal_satisfied_score,
            "progress": evidence.progress_score,
            "no_progress": evidence.no_progress_score,
            "wrong_object": evidence.wrong_object_score,
            "object_lost": evidence.object_lost_score,
        }
        ranked = sorted(
            ((state, float(score)) for state, score in candidates.items() if self._valid(score)),
            key=lambda item: item[1], reverse=True,
        )
        if not ranked:
            return SemanticConsequenceDecision("unknown", 0.0, 0.0, "no valid semantic scores")
        state, score = ranked[0]
        runner_up = ranked[1][1] if len(ranked) > 1 else 0.0
        margin = score - runner_up
        if score < self.minimum_score:
            return SemanticConsequenceDecision("ambiguous", score, margin, "best score is below gate")
        if margin < self.minimum_margin:
            return SemanticConsequenceDecision("ambiguous", score, margin, "semantic hypotheses conflict")
        return SemanticConsequenceDecision(state, score, margin, "strong calibrated semantic evidence")


@dataclass(frozen=True)
class SemanticTemporalConfig:
    no_progress_confirmations: int = 2
    immediate_states: tuple[str, ...] = ("wrong_object", "object_lost")

    def __post_init__(self):
        if self.no_progress_confirmations < 1:
            raise ValueError("no_progress_confirmations must be positive")


class SemanticConsequenceMonitor:
    """Convert typed semantic diagnoses to conservative supervisor events."""

    name = "semantic_task_consequence"

    def __init__(self, config: SemanticTemporalConfig = SemanticTemporalConfig()):
        self.config = config
        self.reset()

    def reset(self) -> None:
        self.no_progress_run = 0

    def observe_decision(self, decision: SemanticConsequenceDecision, *, action_index: int) -> MonitorEvent:
        evidence = {"semantic_state": decision.state, "semantic_reason": decision.reason}
        if decision.state in {"goal_achieved", "progress"}:
            self.no_progress_run = 0
            return MonitorEvent(
                EventType.NORMAL, decision.score, decision.confidence, evidence,
                RecommendedAction.CONTINUE, self.name, action_index,
            )
        if decision.state in {"unknown", "ambiguous"}:
            self.no_progress_run = 0
            return MonitorEvent(
                EventType.OBJECT_AMBIGUOUS, decision.score, decision.confidence, evidence,
                RecommendedAction.REQUEST_MORE_EVIDENCE, self.name, action_index,
            )
        if decision.state == "no_progress":
            self.no_progress_run += 1
            evidence["no_progress_run"] = self.no_progress_run
            if self.no_progress_run < self.config.no_progress_confirmations:
                return MonitorEvent(
                    EventType.OBJECT_AMBIGUOUS, decision.score, decision.confidence, evidence,
                    RecommendedAction.REQUEST_MORE_EVIDENCE, self.name, action_index,
                )
        else:
            self.no_progress_run = 0
        if decision.state in self.config.immediate_states or decision.state == "no_progress":
            return MonitorEvent(
                EventType.OBJECT_FAILURE, decision.score, decision.confidence, evidence,
                RecommendedAction.STOP_AND_REPLAN, self.name, action_index,
            )
        return MonitorEvent(
            EventType.OBJECT_AMBIGUOUS, decision.score, decision.confidence, evidence,
            RecommendedAction.REQUEST_MORE_EVIDENCE, self.name, action_index,
        )
