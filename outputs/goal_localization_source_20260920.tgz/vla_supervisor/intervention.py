"""Conservative intervention planning after supervisor decisions.

This module does not execute robot actions.  It converts fused monitor events
into an auditable directive for the online loop.  Every bridge action must
still pass the normal instruction guard before execution.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
from typing import Iterable, Sequence

import numpy as np

from .events import EventType, MonitorEvent, RecommendedAction, SupervisorDecision


class InterventionMode(str, Enum):
    NOMINAL = "nominal"
    CAUTIOUS_CONTINUE = "cautious_continue"
    REPLAN_SHORT = "replan_short"
    HOLD_THEN_REPLAN = "hold_then_replan"
    RETREAT_THEN_REPLAN = "retreat_then_replan"
    SAFE_STOP = "safe_stop"


@dataclass(frozen=True)
class InterventionConfig:
    nominal_horizon: int = 5
    cautious_horizon: int = 1
    act_on_ambiguity: bool = True
    retreat_on_policy_stall: bool = False
    hold_steps: int = 1
    retreat_steps: int = 2
    retreat_translation_magnitude: float = 0.15

    def __post_init__(self):
        if self.nominal_horizon < 1 or self.cautious_horizon < 1:
            raise ValueError("chunk horizons must be positive")
        if self.cautious_horizon > self.nominal_horizon:
            raise ValueError("cautious horizon cannot exceed nominal horizon")
        if self.hold_steps < 0 or self.retreat_steps < 0:
            raise ValueError("bridge step counts must be non-negative")
        if not 0.0 <= self.retreat_translation_magnitude <= 0.25:
            raise ValueError("retreat magnitude must be in [0, 0.25]")


@dataclass(frozen=True)
class InterventionDirective:
    mode: InterventionMode
    next_chunk_horizon: int
    truncate_remaining_to: int | None = None
    bridge_actions: tuple[tuple[float, ...], ...] = ()
    replan_after_bridge: bool = False
    explanation: str = ""

    def to_dict(self) -> dict:
        value = asdict(self)
        value["mode"] = self.mode.value
        return value


class InterventionPlanner:
    def __init__(self, config: InterventionConfig = InterventionConfig()):
        self.config = config

    @staticmethod
    def _diagnostic_states(events: Iterable[MonitorEvent]) -> set[str]:
        return {
            str(event.evidence.get("diagnostic_state"))
            for event in events if event.evidence.get("diagnostic_state") is not None
        }

    @staticmethod
    def _hold_action(last_action: Sequence[float] | None) -> tuple[float, ...]:
        size = max(7, len(last_action) if last_action is not None else 7)
        action = np.zeros(size, dtype=float)
        if last_action is not None and len(last_action) > 6:
            action[6] = float(last_action[6])
        return tuple(action.tolist())

    def _retreat_action(self, last_action: Sequence[float] | None) -> tuple[float, ...] | None:
        if last_action is None or len(last_action) < 3:
            return None
        translation = np.asarray(last_action[:3], dtype=float)
        norm = float(np.linalg.norm(translation))
        if not np.isfinite(norm) or norm < 1e-6:
            return None
        action = np.asarray(self._hold_action(last_action), dtype=float)
        action[:3] = -self.config.retreat_translation_magnitude * translation / norm
        return tuple(action.tolist())

    def plan(self, decision: SupervisorDecision, events: Iterable[MonitorEvent],
             last_action: Sequence[float] | None = None) -> InterventionDirective:
        events = tuple(events)
        if decision.action is RecommendedAction.SAFE_STOP:
            return InterventionDirective(
                InterventionMode.SAFE_STOP, self.config.cautious_horizon,
                explanation="recovery budget exhausted or explicit safe stop",
            )

        diagnostic_states = self._diagnostic_states(events)
        if decision.request_replan:
            should_retreat = (
                "fixed_obstacle_or_jam" in diagnostic_states
                or (self.config.retreat_on_policy_stall
                    and decision.reason is EventType.POLICY_STALL)
            )
            if should_retreat:
                retreat = self._retreat_action(last_action)
                if retreat is not None:
                    return InterventionDirective(
                        InterventionMode.RETREAT_THEN_REPLAN,
                        self.config.cautious_horizon,
                        bridge_actions=(retreat,) * self.config.retreat_steps,
                        replan_after_bridge=True,
                        explanation=("bounded reverse motion after persistent stall"
                                     if decision.reason is EventType.POLICY_STALL else
                                     "bounded reverse motion after independently diagnosed jam"),
                    )
            if decision.reason is EventType.INSTRUCTION_UNSAFE:
                return InterventionDirective(
                    InterventionMode.REPLAN_SHORT, self.config.cautious_horizon,
                    replan_after_bridge=True,
                    explanation="unsafe unexecuted instruction; discard and replan",
                )
            hold = self._hold_action(last_action)
            return InterventionDirective(
                InterventionMode.HOLD_THEN_REPLAN,
                self.config.cautious_horizon,
                bridge_actions=(hold,) * self.config.hold_steps,
                replan_after_bridge=True,
                explanation="freeze translation/rotation before replanning",
            )

        ambiguous = any(event.event_type in {
            EventType.EXECUTION_AMBIGUOUS, EventType.OBJECT_AMBIGUOUS
        } for event in events)
        if ambiguous:
            if not self.config.act_on_ambiguity:
                return InterventionDirective(
                    InterventionMode.CAUTIOUS_CONTINUE,
                    self.config.nominal_horizon,
                    explanation=("record ambiguity without queue mutation until an "
                                 "independent diagnostic modality is online"),
                )
            return InterventionDirective(
                InterventionMode.CAUTIOUS_CONTINUE,
                self.config.cautious_horizon,
                truncate_remaining_to=self.config.cautious_horizon,
                explanation="retain feedback control while collecting ambiguity evidence",
            )
        return InterventionDirective(
            InterventionMode.NOMINAL, self.config.nominal_horizon,
            explanation="no actionable or ambiguous evidence",
        )
